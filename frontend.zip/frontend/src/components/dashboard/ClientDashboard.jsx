export default function ClientDashboard() {
  return (
    <div>
      <h1>Dashboard do Cliente</h1>
      <p>Ver e gerir reservas pessoais.</p>
    </div>
  );
}