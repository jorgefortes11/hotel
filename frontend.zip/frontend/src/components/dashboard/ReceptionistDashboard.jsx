export default function ReceptionistDashboard() {
  return (
    <div>
      <h1>Dashboard da Rececionista</h1>
      <p>Gestão de reservas e clientes.</p>
    </div>
  );
}