export default function AdminDashboard() {
  return (
    <div>
      <h1>Dashboard do Administrador</h1>
      <p>Gestão de utilizadores, quartos e reservas.</p>
    </div>
  );
}
